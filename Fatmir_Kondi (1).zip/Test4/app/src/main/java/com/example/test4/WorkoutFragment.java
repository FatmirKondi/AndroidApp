package com.example.test4;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.fragment.app.Fragment;


public class WorkoutFragment extends Fragment {


    public WorkoutFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rview = inflater.inflate(R.layout.fragment_workout, container, false);
        WebView webView = (WebView)rview.findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("https://www.acefitness.org/education-and-resources/lifestyle/blog/6593/top-25-at-home-exercises/");


        return rview;
    }
    }