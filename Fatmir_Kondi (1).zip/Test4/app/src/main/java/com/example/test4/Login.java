package com.example.test4;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    private int counter = 3;
    private Button loginbutton;
    private TextView textviewinfo;
    private boolean loggedin = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText username = (EditText) findViewById(R.id.editTextTextPersonName);
        final EditText password = (EditText) findViewById(R.id.editTextTextPersonName2);
        final MediaPlayer mp = MediaPlayer.create(Login.this,R.raw.buttonsound);
        textviewinfo = (TextView) findViewById(R.id.textView1);
        loginbutton = (Button)findViewById(R.id.button);
        textviewinfo.setText("Remaning Attempts: 3");

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                validate(username.getText().toString(),
                        password.getText().toString());
                if (loggedin == true){
                    Toast.makeText(Login.this, "Logged In", Toast.LENGTH_SHORT).show();
                    mp.start();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        public void onCompletion(MediaPlayer mp) {
                            mp.release();
                        }
                    });
                }
            }
        });
    }
    private void validate (String username, String password){
        if ((username.equals("Fatmir")) && (password.equals("password"))){

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);

            loggedin = true;
        } else {
            Toast.makeText(Login.this, "Wrong Username or Password", Toast.LENGTH_SHORT).show();
            counter --;
            textviewinfo.setText("Remaining Attempts: " +
                    String.valueOf(counter));
            if (counter == 0){
                loginbutton.setEnabled(false);
            }
        }
    }
}