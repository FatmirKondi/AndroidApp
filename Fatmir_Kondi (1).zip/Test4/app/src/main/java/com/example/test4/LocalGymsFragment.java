package com.example.test4;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class LocalGymsFragment extends Fragment {

        MapView mMapView;
        private GoogleMap googleMap;

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_local_gyms, container, false);

            mMapView = (MapView) rootView.findViewById(R.id.mapView);
            mMapView.onCreate(savedInstanceState);

            mMapView.onResume();

            try {
                MapsInitializer.initialize(getActivity().getApplicationContext());
            } catch (Exception e) {
                e.printStackTrace();
            }

            mMapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap mMap) {
                    googleMap = mMap;


                    LatLng PerfectFitness = new LatLng(41.332542, 19.827883);
                    googleMap.addMarker(new MarkerOptions().position(PerfectFitness).title("PerfectFitness").snippet(""));
                    LatLng FitExpress = new LatLng(41.332657, 19.803931);
                    googleMap.addMarker(new MarkerOptions().position(FitExpress).title("FitExpress").snippet(""));
                    LatLng AlbaniaGym = new LatLng(41.332560, 19.817380);
                    googleMap.addMarker(new MarkerOptions().position(AlbaniaGym).title("AlbaniaGym").snippet(""));
                    LatLng CityFitnessClub = new LatLng(41.331065, 19.818638);
                    googleMap.addMarker(new MarkerOptions().position(CityFitnessClub).title("CityFitnessClub").snippet(""));
                    LatLng EvolutionFitnessCenter = new LatLng(41.329496, 19.809890);
                    googleMap.addMarker(new MarkerOptions().position(EvolutionFitnessCenter).title("EvolutionFitnessCenter").snippet(""));
                    LatLng AngelsFitnessGym = new LatLng(41.323437,  19.795545);
                    googleMap.addMarker(new MarkerOptions().position(AngelsFitnessGym).title("AngelsFitnessGym").snippet(""));
                    LatLng MyGym = new LatLng(41.325302,  19.811749);
                    googleMap.addMarker(new MarkerOptions().position(MyGym).title("MyGym").snippet(""));
                    LatLng GoldenGym = new LatLng(41.322754, 19.816581);
                    googleMap.addMarker(new MarkerOptions().position(GoldenGym).title("GoldenGym").snippet(""));
                    LatLng BodyCode = new LatLng(41.318257, 19.809308);
                    googleMap.addMarker(new MarkerOptions().position(BodyCode).title("BodyCode").snippet(""));
                    LatLng StaticFitnessClub = new LatLng(41.314748, 19.816221);
                    googleMap.addMarker(new MarkerOptions().position(StaticFitnessClub).title("StaticFitnessClub").snippet(""));
                    LatLng TechFit = new LatLng(41.327755, 19.826575);
                    googleMap.addMarker(new MarkerOptions().position(TechFit).title("TechFit").snippet(""));

                    LatLng Tirana = new LatLng(41.328546, 19.818416);

                    CameraPosition cameraPosition = new CameraPosition.Builder().target(Tirana).zoom(14).build();
                    googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
            });

            return rootView;
        }


        @Override
        public void onResume() {
            super.onResume();
            mMapView.onResume();
        }

        @Override
        public void onPause() {
            super.onPause();
            mMapView.onPause();
        }

        @Override
        public void onDestroy() {
            super.onDestroy();
            mMapView.onDestroy();
        }

        @Override
        public void onLowMemory() {
            super.onLowMemory();
            mMapView.onLowMemory();
        }
    }