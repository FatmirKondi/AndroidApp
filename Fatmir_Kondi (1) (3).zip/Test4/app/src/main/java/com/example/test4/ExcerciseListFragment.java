package com.example.test4;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class ExcerciseListFragment extends Fragment {

    ArrayList <String> exerciseList;
    ArrayAdapter<String> adapter;
    ListView listView;
    EditText itemText;
    Button addButton;
    public ExcerciseListFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_excercise_list, container, false);
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        listView = (ListView) view.findViewById(R.id.listView);
        itemText = (EditText) view.findViewById(R.id.addText);
        addButton = (Button) view.findViewById(R.id.addButton);
        exerciseList = new ArrayList<>();
        adapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_list_item_multiple_choice, exerciseList);
        View.OnClickListener addListener = new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                exerciseList.add(itemText.getText().toString());
                itemText.setText("");
                adapter.notifyDataSetChanged();
            }

        };

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){

            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id){

                SparseBooleanArray positionChecker = listView.getCheckedItemPositions();
                int count = listView.getCount();
                for (int item = count - 1; item>=0; item--){
                    if (positionChecker.get(item)){
                        adapter.remove(exerciseList.get(item));

                    }
                }
                positionChecker.clear();
                adapter.notifyDataSetChanged();
                return false;
            }
        });
        addButton.setOnClickListener(addListener);
        listView.setAdapter(adapter);
        return view;
    }
}